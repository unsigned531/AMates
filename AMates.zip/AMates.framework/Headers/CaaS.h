//
//  A-Mates.h
//  A-Mates
//
//  Created by Roman Chekun on 18.05.21.
//

#import <Foundation/Foundation.h>

//! Project version number for A-Mates.
FOUNDATION_EXPORT double A-MatesVersionNumber;

//! Project version string for A-Mates.
FOUNDATION_EXPORT const unsigned char A-MatesVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <A-Mates/PublicHeader.h>


